package com.redbusdemo.qa.test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.redbusdemo.qa.base.Basetest;
import com.redbusdemo.qa.page.Homepage;


public class TestHomepage extends Basetest {
	Homepage hp;
	
	@BeforeClass
	public void openApp()
	{
		openBrowser();
		hp = new Homepage(driver);
	}
	
	@Test(testName="title",priority='1')
	public void test_homepagegettitle()
	{
		hp.gettitle();
		extentTest.pass("Test Passed");
	}
	
	
	@Test(testName="busticket", priority='2')
	public void test_Clickonbusticket()
	{
		hp.Clickonbusticket();
		System.out.println(driver.getTitle());
		extentTest.pass("Test Passed");
	}
	

	@Test(testName="cabrental", priority='3')
	public void test_Clickoncabrental()
	{
		hp.Clickoncabrental();
		System.out.println(driver.getTitle());
		extentTest.pass("Test Passed");
	}
	

	
	@Test(testName="redRail",priority='4')
	public void test_ClickonredRail() throws InterruptedException
	{
		hp.ClickonredRail();
		System.out.println(driver.getTitle());
		extentTest.pass("Test Passed");
	}

}
