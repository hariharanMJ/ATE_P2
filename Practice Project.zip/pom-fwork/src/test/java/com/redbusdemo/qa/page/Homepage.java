package com.redbusdemo.qa.page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.redbusdemo.qa.base.Basetest;

public class Homepage extends Basetest {
	@FindBy(xpath = "//span[normalize-space()='Bus Tickets']")
	WebElement busticket;
	
	@FindBy(xpath = "//span[normalize-space()='Cab Rental']")
	WebElement cabrental;
	
	@FindBy(xpath = "//a[normalize-space()='redRail']")
	WebElement redRail;
	

	
	public Homepage(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
	}
	
	public void gettitle()
	{
		System.out.println(driver.getTitle());
	}
	
	
	public void Clickonbusticket()
	{
		busticket.click();
	}
	
	public void Clickoncabrental()
	{
		cabrental.click();
	}
	
	public void ClickonredRail()
	{
		redRail.click();
	}
	


}
